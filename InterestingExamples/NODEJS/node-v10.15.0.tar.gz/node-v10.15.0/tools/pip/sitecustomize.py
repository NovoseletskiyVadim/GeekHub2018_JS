import os
import site
site.addsitedir(os.path.dirname(os.path.realpath(__file__)) + '/site-packages')
